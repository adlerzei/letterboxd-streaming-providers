"use strict";

//for compatibility reasons
var browser = chrome;
