# Letterboxd Streaming Services

## What?
This is a extension for common web browsers written with the WebExtensions API.

## Purpose
This extension adds a filter for some streaming services (namely Netflix, Amazon Prime) to Letterboxd (https://www.letterboxd.com/), so that you can see, which movies are included into your streaming flat rate.

### Important Notice
This is a third party extension and is not related to the Letterboxd developer team in any way.

## For which browsers?
The extension can be added into Chrome, Firefox and Opera.

## Acknowledgements
Thanks to everyone using and supporting the extension. Philipp Emmer is especially mentioned for the idea for this extension.